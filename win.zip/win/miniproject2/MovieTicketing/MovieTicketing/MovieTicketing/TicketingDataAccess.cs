﻿using System;
using System.Data.SqlClient;

namespace MovieTicketing
{
    public class TicketingDataAccess
    {
        string ConnectionString = "Data Source=.;Initial Catalog=MovieTicketing;User ID=sa;Password=wipro@123";

        public bool AddMovie(Movies obj)
        {
            bool status = false;
            if (obj == null)
            {
                return status;
            }
            using (SqlConnection con = new SqlConnection(ConnectionString))
            {

                SqlCommand cmd = new SqlCommand("Insert into Movies( MOVIENAME,DIRECTOR,PLAYSPERDAY,TICKETPRICE) VALUES (@MN,@DIR,@PPD,@TP) ", con);
                //cmd.Parameters.AddWithValue("@MID",obj.MovieID);
                cmd.Parameters.AddWithValue("@MN",obj.MovieName);
                cmd.Parameters.AddWithValue("@DIR",obj.DirectorName);
                cmd.Parameters.AddWithValue("@PPD",obj.PlaysPerDay);
                cmd.Parameters.AddWithValue("@TP",obj.TicketPrice);
                con.Open();
                int TotalRowAffected = cmd.ExecuteNonQuery();
                if(TotalRowAffected ==1)
                {
                    status = true;
                }
            }
                return status; 
        }

        public bool AddTheatre(Theatres obj)
        {
            bool status = false;
            if (obj == null)
            {
                return status;
            }
            using (SqlConnection con = new SqlConnection(ConnectionString))
            {

                SqlCommand cmd = new SqlCommand("Insert into Theatres(THEATRENAME,SEATINGCAPACITY) VALUES (@TN,@SC) ", con);
               // cmd.Parameters.AddWithValue("@TID", obj.TheatreID);
                cmd.Parameters.AddWithValue("@TN", obj.TheatreName);
                cmd.Parameters.AddWithValue("@SC", obj.SeatingCapacity);
                con.Open();
                int TotalRowAffected = cmd.ExecuteNonQuery();
                if (TotalRowAffected == 1)
                {
                    status = true;
                }
            }
            return status;
        }

        public bool AddShow(Shows obj)
        {
            bool status = false;
            if (obj == null)
            {
                return status;
            }
            using (SqlConnection con = new SqlConnection(ConnectionString))
            {

                SqlCommand cmd = new SqlCommand("Insert into Shows(MOVIEID,STARTDATE,STRATIME,THEATREID,ENDDATE,ENDTIME) VALUES (@MID,@SD,@ST,@TID,@ED,@ET) ", con);
                cmd.Parameters.AddWithValue("@MID", obj.MovieID);
                //cmd.Parameters.AddWithValue("@SID", obj.ShowID);
                cmd.Parameters.AddWithValue("@SD", obj.StartDate);
                cmd.Parameters.AddWithValue("@ST", obj.StartTime);
                cmd.Parameters.AddWithValue("@TID", obj.TheatreID);
                cmd.Parameters.AddWithValue("@ED", obj.EndDate);
                cmd.Parameters.AddWithValue("@ET", obj.EndTime);
                con.Open();
                int TotalRowAffected = cmd.ExecuteNonQuery();
                if (TotalRowAffected == 1)
                {
                    status = true;
                }
            }
            return status;
        }

        public string AddTicket(Tickets obj)
        {

            //            This method should take the reference of the of the Tickets object containing the ticket information to
            //be added into the database.The REFERENCECODE should be generated as per the procedure
            //mentioned in Appendix 1.The amount to be calculated as [Numberofpersons * Ticker price of the
            //movie]
            //The ticket details should be added into the Tickets table. If the insertion is successful, should return
            //“reference code” else return “null”. Note: If the object reference is null return “null” 
            //            Procedure of generating the reference code is mentioned below.
          
            if (obj == null){
                return null;
            }
            string movieName = string.Empty;
            decimal price = 0;
            using (SqlConnection con = new SqlConnection(ConnectionString))
            {

                SqlCommand cmd = new SqlCommand("SELECT MOVIENAME,Ticketprice from Movies where MOVIEID = (Select MOVIEID from shows where SHOWID = @SHOWID group by movieid ) ", con);
                cmd.Parameters.AddWithValue("@SHOWID", obj.ShowID);
                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    dr.Read();
                    movieName = dr["moviename"].ToString();
                    price = decimal.Parse(dr["TICKETPRICE"].ToString());
                }
            }
            //int price = 0;
            //using (SqlConnection con = new SqlConnection(ConnectionString))
            //{

            //    SqlCommand cmd = new SqlCommand("SELECT TICKETPRICE from MOvies where MOVIEID = (Select MOVIEID from shows where SHOWID = @SHOWID) ", con);
            //    cmd.Parameters.AddWithValue("@id", obj.ShowID);
            //    con.Open();
            //    price = int.Parse(cmd.ExecuteScalar().ToString());
            //}

            Random rnd = new Random();
            int rndnum = rnd.Next(1, 1000);
            decimal amount = decimal.Parse(obj.NumberofPersons.ToString()) * price;
            string referencecode = string.Format("{0}{1}{2}{3}{4}{5}{6}{7}", char.ToUpper(obj.CustomerName[0]),char.ToUpper(obj.CustomerName[1]),obj.NumberofPersons, char.ToUpper(movieName[0]), char.ToUpper(movieName[1]),obj.BookingDate.Day,obj.BookingDate.Month,rndnum);

            using (SqlConnection con = new SqlConnection(ConnectionString))
            {

                SqlCommand cmd = new SqlCommand("Insert into Tickets(SHOWID,REFERENCECODE,CUSTOMERname,NUMBEROFPERSONS,BOOKINGDATE,AMOUNT,TICKETSTATUS) VALUES (@SID,@SD,@cn,@ST,@TID,@ED,@ET) ", con);
                //cmd.Parameters.AddWithValue("@MID", obj.TicketID);
                cmd.Parameters.AddWithValue("@SID",obj.ShowID );
                cmd.Parameters.AddWithValue("@SD", referencecode);
                cmd.Parameters.AddWithValue("@cn", obj.CustomerName);

                cmd.Parameters.AddWithValue("@ST", obj.NumberofPersons);
                cmd.Parameters.AddWithValue("@TID", obj.BookingDate);
                cmd.Parameters.AddWithValue("@ED", amount);
                cmd.Parameters.AddWithValue("@ET", obj.TicketStatus);
                con.Open();
                int TotalRowAffected = cmd.ExecuteNonQuery();
                if(TotalRowAffected >0)
                {
                    return referencecode;
                }
                else
                {
                    return null;
                }

        }



    }

        public int DeleteMovie(int intMovieID)
        {
            int total = 0;
            SqlConnection con1 = new SqlConnection(ConnectionString);


            SqlCommand cmd = new SqlCommand("select showid from shows where movieid = @id ", con1);
            cmd.Parameters.AddWithValue("@id", intMovieID);
            con1.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.HasRows)
            {
                while (dr.Read())
                {

                    int showid = int.Parse(dr["showid"].ToString());

                    SqlConnection con2 = new SqlConnection(ConnectionString);
                    SqlCommand cmd2 = new SqlCommand("delete from tickets where showid = @para", con2);
                    cmd2.Parameters.AddWithValue("@para", showid);
                    con2.Open();
                    int gotrow = cmd2.ExecuteNonQuery();
                    con2.Close();
                    total = total + gotrow;

                }
            }
            con1.Close();

            SqlConnection last2 = new SqlConnection(ConnectionString);
            SqlCommand cmd3 = new SqlCommand("delete from shows where movieid = @para", last2);
            cmd3.Parameters.AddWithValue("@para", intMovieID);
            last2.Open();
            int gotrows = cmd3.ExecuteNonQuery();
            last2.Close();
            total = total + gotrows;


            SqlConnection last = new SqlConnection(ConnectionString);
            SqlCommand cmd4 = new SqlCommand("delete from movies where movieid = @para", last);
            cmd4.Parameters.AddWithValue("@para", intMovieID);
            last.Open();
            gotrows = cmd4.ExecuteNonQuery();
            if (gotrows == 0)
            {
                return total;
            }
            last.Close();
            total = total + gotrows;
            return total;






        }
    }
}




//public int DeleteMovie(int intMovieID)
//{
//    int total = 0;
//    SqlConnection con1 = new SqlConnection(ConnectionString);


//    SqlCommand cmd = new SqlCommand("select showid from shows where movieid = @id ", con1);
//    cmd.Parameters.AddWithValue("@id", intMovieID);
//    con1.Open();
//    SqlDataReader dr = cmd.ExecuteReader();
//    if (dr.HasRows)
//    {
//        while (dr.Read())
//        {

//            int showid = int.Parse(dr["showid"].ToString());

//            SqlConnection con2 = new SqlConnection(ConnectionString);
//            SqlCommand cmd2 = new SqlCommand("delete from tickets where showid = @para", con2);
//            cmd2.Parameters.AddWithValue("@para", showid);
//            con2.Open();
//            int gotrow = cmd2.ExecuteNonQuery();
//            con2.Close();
//            total = total + gotrow;

//        }
//    }
//    else
//    {
//        return 0;
//    }
//    con1.Close();

//    if (total > 0)
//    {
//        SqlConnection last2 = new SqlConnection(ConnectionString);
//        SqlCommand cmd3 = new SqlCommand("delete from shows where movieid = @para", last2);
//        cmd3.Parameters.AddWithValue("@para", intMovieID);
//        last2.Open();
//        int gotrows = cmd3.ExecuteNonQuery();
//        last2.Close();
//        total = total + gotrows;
//        if (gotrows > 0)
//        {
//            gotrows = 0;
//            SqlConnection last = new SqlConnection(ConnectionString);
//            SqlCommand cmd4 = new SqlCommand("delete from Movies where movieid = @para", last);
//            cmd4.Parameters.AddWithValue("@para", intMovieID);
//            last.Open();
//            gotrows = cmd4.ExecuteNonQuery();
//            last.Close();
//            if (gotrows == 1)
//            {
//                return total + gotrows;
//            }
//            else
//            {
//                return 0;
//            }


//        }
//        else
//        {
//            return 0;
//        }
//    }
//    else
//    {
//        return 0;
//    }
//}
