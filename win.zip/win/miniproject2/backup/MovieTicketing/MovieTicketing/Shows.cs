﻿using System;


namespace MovieTicketing
{
    public class Shows
    {
        public int ShowID { get; set; }
        public int TheatreID { get; set; }
        public int MovieID { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public DateTime StartTime { get; set; }
        public DateTime EndTime { get; set; }
    }
}
