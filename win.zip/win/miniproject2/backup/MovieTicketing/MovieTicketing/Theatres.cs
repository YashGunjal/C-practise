﻿using System;


namespace MovieTicketing
{
    public class Theatres
    {
        public int TheatreID { get; set; }
        public string TheatreName { get; set; }
        public int SeatingCapacity { get; set; }

    }
}
