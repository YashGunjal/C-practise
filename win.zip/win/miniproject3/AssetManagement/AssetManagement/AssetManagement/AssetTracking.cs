﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetManagement
{
    public class AssetTracking
    {
        const string ConnectionString = "Data Source=.;Initial Catalog=AssetManagement;User ID=sa;Password=wipro@123";
        public bool AddAsset(Asset obj)
        {
            if(obj == null)
            {
                return false;
            }
            else
            {
                //Step 1:   Extract first two characters of the Asset type. 
                //Step 2:   Generate a random number between 1 and 1000 and append it to the first two characters of the asset type
                Random rnd = new Random();
                int rndnum = rnd.Next(1, 1000);
                obj.SerialNo = string.Format("{0}{1}{2}",obj.AssetType[0],obj.AssetType[1],rndnum);
                SqlConnection con = new SqlConnection(ConnectionString);
                SqlCommand cmd = new SqlCommand("insert into asset (assettype,serialno,procurementdate,taggingstatus) values(@typ,@no,@pd,@ts)", con);
                cmd.Parameters.AddWithValue("@typ", obj.AssetType);
                cmd.Parameters.AddWithValue("@no", obj.SerialNo);
                cmd.Parameters.AddWithValue("pd", obj.ProcurementDate);
                cmd.Parameters.AddWithValue("@ts", obj.TaggingStatus);
                con.Open();
                int rows = cmd.ExecuteNonQuery();
                con.Close();
                if(rows ==1)
                {
                    return true;
                }
                else
                {
                    return false;
                } 
            }
        }

        public bool ModifyAsset(Asset obj)
        {
            if (obj == null)
            {
                return false;
            }
            else
            {
                SqlConnection con = new SqlConnection(ConnectionString);
                SqlCommand cmd = new SqlCommand("Update asset set assettype =@typ , serialno =@no, procurementdate =@pd, taggingstatus=@ts where assetid = @aid", con);
                cmd.Parameters.AddWithValue("@tpy", obj.AssetType);
                cmd.Parameters.AddWithValue("@no", obj.SerialNo);
                cmd.Parameters.AddWithValue("pd", obj.ProcurementDate);
                cmd.Parameters.AddWithValue("@ts", obj.TaggingStatus);
                cmd.Parameters.AddWithValue("@aid", obj.AssetID);
                con.Open();
                int rows = cmd.ExecuteNonQuery();
                con.Close();
                if (rows == 1)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }

        public bool TagAsset(AssetTagging obj)
        {
            if (obj == null)
            {
                return false;
            }
            else
            {
                //This method should tag an asset to the defined employee. Follow the below procedure to tag the asset. 
                //     To tag an asset, insert the asset tagging details into the AssetTagging table of the Asset management database. 
                //     While inserting, check if the asset is already tagged to an employee. Same asset can’t tagged to multiple employees.
                //    For tagging any asset the asset must be in free pool. If the tagging status of the asset is “Free Pool”,
                //then insert the record into AssetTagging table of the asset management
                //    database.Also change the tagging status of the asset in the asset table to “Tagged”. Upon successful tagging, return “true”.
                // If either the asset is already tagged OR asset tagging reference is pointing to null, return “false” 
                SqlConnection con = new SqlConnection(ConnectionString);
                SqlCommand cmd = new SqlCommand("select taggingstatus from asset where assetid = @id", con);
                cmd.Parameters.AddWithValue("@id", obj.AssetID);
                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                
                if (dr.HasRows)
                {
                    dr.Read();
                    string status = dr["taggingstatus"].ToString();
                    if (status == "Free Pool")
                    {
                        SqlConnection con1 = new SqlConnection(ConnectionString);
                        SqlCommand cmd1 = new SqlCommand("update asset set taggingstatus = @st where assetid = @id ", con1);
                        cmd1.Parameters.AddWithValue("@id", obj.AssetID);
                        cmd1.Parameters.AddWithValue("@st", "Tagged");
                        con1.Open();
                        
                        int updaterows = cmd1.ExecuteNonQuery();
                        con1.Close();

                        SqlConnection con2 = new SqlConnection(ConnectionString);
                        SqlCommand cmd3 = new SqlCommand("insert into assetTagging (Assetid,EmployeeID,Taggingdate,Releasedate) values (@id,@eid,@tdate,null) ", con2);
                        cmd3.Parameters.AddWithValue("@id", obj.AssetID);
                        cmd3.Parameters.AddWithValue("@eid", obj.EmployeeID);
                        cmd3.Parameters.AddWithValue("@tdate", obj.TaggingDate);
                        //cmd3.Parameters.AddWithValue("@rdate", null);
                        
                        con2.Open();
                        
                        int updaterow = cmd3.ExecuteNonQuery();
                        con2.Close();
                        if (updaterow==1 && updaterows == 1)
                        {
                            return true;
                        }
                        con.Close();

                    }
                    else
                    {
                        return false;
                    }
                }



                   return false;
            }
        }

        public bool DeTagAsset(int intAssetId)
        {
            if (intAssetId == 0)
            {
                return false;
            }
            else
            {
                SqlConnection con = new SqlConnection(ConnectionString);
                SqlCommand cmd = new SqlCommand("update asset set taggingstatus = @st where assetid = @id ", con);
                cmd.Parameters.AddWithValue("@id", intAssetId);
                cmd.Parameters.AddWithValue("@st", "Free Pool");

                con.Open();
                int rows = cmd.ExecuteNonQuery();
                con.Close();
                if (rows == 1)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }
    }
}
