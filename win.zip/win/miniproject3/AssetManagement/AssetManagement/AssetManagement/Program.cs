﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetManagement
{
    class Program
    {
        static void Main(string[] args)
        {
            int input1 = 1204;
            int input2 = 1342;
            int input3 = 4035;
            int input4 = 1452;

            double num = double.Parse(string.Format("{0}{1}{2}{3}", input1, input2, input3, input4));
            SortedList<double, int> lis = new SortedList<double, int>();
            while(num != 0)
            {
                double digit =num % 10;
                if(lis.ContainsKey(digit))
                {
                    lis[digit]= lis[digit] + 1;
                }
                else
                {
                    lis.Add(digit, 1);
                }
                num = num / 10;
                num = double.Parse(string.Format("{0:N0}", num));
                Console.WriteLine("currentdigit" + num);
                for (int i = 0; i < lis.Count; i++)
                {
                    Console.WriteLine("key: {0}, value: {1}", lis.Keys[i], lis.Values[i]);
                }
            }

            for (int i = 0; i < lis.Count; i++)
            {
                Console.WriteLine("key: {0}, value: {1}", lis.Keys[i], lis.Values[i]);
            }
            int lowest = 10000;
            foreach(var numm in lis.Values)
            {
                if(numm<lowest)
                {
                    lowest = numm;
                }
            }

            Console.WriteLine(lowest);
            int index =lis.IndexOfValue(lowest);
            Console.WriteLine(lis[index]);
        







            //int num = 987;
            //int numbers = 0;
            //int sum = 0;
            //Console.WriteLine("num" + num);


            //while (num != 0)
            //{
            //    Console.WriteLine("            Set");
            //    Console.WriteLine("num" + num);


            //    int digit = num % 10;
            //    sum += digit;
            //    numbers += 1;
            //    num = num / 10;
            //    Console.WriteLine("Sum" + sum);
            //    Console.WriteLine("number" + numbers);


            //}
            //Console.WriteLine("Sum" + sum);
            //Console.WriteLine("number" + numbers);
            //double sum1 = sum;
            //double numbers1 = numbers;
            //double output =(double) sum1 /(double) numbers1;
            //Console.WriteLine(double.Parse(string.Format("{0:N2}", output)));
        }
    }
}
