﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MP3__TechModule3
{
    class Program
    {
        static void Main(string[] args)
        {
            Employee Rohit = new Employee("Rohit", "Sharma", "rohit.sharma@cricket.com", 1989, 07, 24);
            Rohit.Annual_salary = 4500000;
            Console.WriteLine(Rohit.Annual_salary);
            Rohit.Display();
        }
    }
}
