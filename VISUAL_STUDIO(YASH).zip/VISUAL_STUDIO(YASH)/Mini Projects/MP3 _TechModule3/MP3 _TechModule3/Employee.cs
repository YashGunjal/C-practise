﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MP3__TechModule3
{
    class Employee :Person
    {
        internal double Annual_salary { get; set; }
        private string Natiponal_Insurance_number { get; set; }
        public Employee(string FN, string LN, string EA, params int[] dates):base(FN, LN, EA, dates)
        {
        }
        public Employee(string FN, string LN, string EA ) : base(FN, LN, EA )
        {
        }
        public Employee(string FN, string LN,  params int[] dates) : base(FN, LN, dates)
        {
        }

        public void Display()
        {
            Console.WriteLine("\nEmployee details of {0}", FirstName);
            Console.WriteLine("EmployeeName : {0}", FirstName + " " + LastName);
            Console.WriteLine("Your Screen Name : {0}", ScreenName);
            Console.WriteLine("is birthday {0}", IsBirthDay);
            Console.WriteLine("is adult {0}", IsAdult);
            Console.WriteLine("Your Sunsign : {0} ", SunSign);
            Console.WriteLine("E-mail : {0}", EmailAddress);
           
        }
    }
}
