﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeManagement.Utility
{
    public class EmployeeUtility
    {
        public void GenerateUserName(Employee obj,int EmployeeCount)
        {
            
            int third = obj.FirstName[0] + obj.FirstName.Length;
            int fourth = obj.LastName[0] + obj.LastName.Length;
            char thr = (char)third;
            char four = (char)fourth;

            //char first = obj.FirstName[0];
            //char second = obj.LastName[0];
            //int third = first + 4;
            //int fourth = second + 5;
            //char thr = (char)third;
            //char four = (char)fourth;

            obj.UserID = string.Format("{0}{1}{2}{3}{4}{5}",char.ToUpper(thr), char.ToUpper(four), SumDigits(obj.BirthYear), SumDigits(obj.BirthMonth), SumDigits(obj.BirthDay), EmployeeCount);


        }

        public string SumDigits(int value)
        {
            int sum = 0;
            while (value != 0)
            {
                int digit = value % 10;
                sum = sum + digit;
                value = value / 10;
            }
            return sum.ToString();
        }

     
    }
}
