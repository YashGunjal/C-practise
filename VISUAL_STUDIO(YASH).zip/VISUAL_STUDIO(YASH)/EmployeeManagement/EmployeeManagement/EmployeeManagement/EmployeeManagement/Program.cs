﻿using EmployeeManagement.Utility;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeManagement
{
    class Program
    {
        static void Main(string[] args)
        {
            Employee objEmployee = new Employee("john", "smith", 2012, 12, 01, "B.E.", 5);
            
                EmployeeUtility objUtility = new EmployeeUtility();

                objUtility.GenerateUserName(objEmployee, 0);

            EmployeeData objEmployeeManagement = new EmployeeData();

                string strUserID = objEmployeeManagement.AddEmployee(objEmployee);

                Console.WriteLine(strUserID);

            }

        }
    }

