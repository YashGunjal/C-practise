﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeManagement
{
    public class Person
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public int BirthYear { get; set; }
        public int BirthMonth { get; set; }
        public int BirthDay { get; set; }

        public Person() { }
        public Person(string FirstName, string LastName, int BirthYear, int BirthMonth, int BirthDay)
        {
            this.FirstName = FirstName;
            this.LastName = LastName;
            this.BirthYear = BirthYear;
            this.BirthMonth = BirthMonth;
            this.BirthDay = BirthDay;
        }
    }
}
