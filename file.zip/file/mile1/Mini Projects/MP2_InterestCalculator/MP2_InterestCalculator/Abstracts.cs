﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MP2_InterestCalculator
{
    abstract class AccountCommon : IAccount
    {
        public double Interest_rate { set; get; }
        public double Amount { set; get; }
        public abstract double CalculateInterest();
    }

  
}
