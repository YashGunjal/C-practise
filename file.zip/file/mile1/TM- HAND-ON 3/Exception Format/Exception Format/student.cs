﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exception_Format
{
    class student
    {
        public string name
        {
            set
            {
                if (string.IsNullOrEmpty(value))
                    throw new EmptyInputException("Empty input for Firstname");
                if (string.IsNullOrWhiteSpace(value))
                    throw new EmptyInputException("Empty or whitespace input is not valid");
                char[] letters = value.ToCharArray();
                foreach (char ch in letters)
                {
                    if (Char.IsLetter(ch))
                    {
                        throw new OtherthanAlphabetsException("Input must only contain Alphabets");
                    }
                }
            }
            get { return name; }

        }
        public Hashtable hashTable = new Hashtable();
    }
}
