﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FileHandling_third
{
    class Program
    {
        static void Main(string[] args)
        {

            string filepath = @"D:\newfile.txt ";
            StreamWriter sw = new StreamWriter(filepath);
            sw.Write("some words");
            sw.WriteLine();
            sw.Write("some more words");
            sw.Close();

            Console.WriteLine("taking out text using stramReader");

            StreamReader rd = new StreamReader(filepath);
            Console.WriteLine(  rd.ReadToEnd());
            rd.Close();

        }
    }
}
