﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Employee__class;

namespace Employee__class
{
    class Program
    {
        static void Main(string[] args)
        {
            Employee Emp_number1 = new Employee("Rajat Sharma",5000000);
            Emp_number1.CalculateNetPay();
            Emp_number1.Display();
        }
    }
}
