﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Employee__class
{
    public class Employee
    {
        private string EmployeeName;
        private double BasicSalary;
        private double HRA;
        private double DA;
        private double GrossSalary;
        private double NetSalary;
        private double TAX;

        public Employee(string Em, double bs)
        {
            EmployeeName = Em;
            BasicSalary  = bs;
            
        }

        public void CalculateNetPay()
        {
            HRA = BasicSalary *.15;
            DA = BasicSalary * .10;
            GrossSalary = BasicSalary + HRA + DA;
            TAX = GrossSalary * .08;
            NetSalary = GrossSalary - TAX;


        }

        public void Display()
        {
            Console.WriteLine("EmployeeName : {0}", EmployeeName);
            Console.WriteLine("BasicSalary : {0}",BasicSalary);
            Console.WriteLine("HRA: {0}",HRA);
            Console.WriteLine("DA: {0}", DA);
            Console.WriteLine("GrossSalary: {0}", GrossSalary);
            Console.WriteLine("NetSalary: {0}", NetSalary);
            Console.WriteLine("TAX : {0}",TAX);
        }
    }


}
