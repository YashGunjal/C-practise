﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Occurance_of_second
{
    class Program
    {
        static void Main(string[] args)

{
            //dynamic input;
            Console.WriteLine("Enter two numbers\n we will find number of occurance of second number in first");
            int num1 = Convert.ToInt32(Console.ReadLine());

            int num2 = Convert.ToInt32(Console.ReadLine());
            int count = 0;


            while (num1 != 0)
            {
                int digit = num1 % 10;
                if (digit == num2)
                {
                    count = count + 1;
                }
                num1 /= 10;
            }

            Console.WriteLine("occurance found:");
            Console.WriteLine(count);
            Console.ReadKey();
        }
    }
}
