﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication2
{
    class ConstituentOfString
    {
        static void Main(string[] args)
        {
            int input;
            Console.WriteLine("Enter an Alphanumeric");
            input = Convert.ToInt32(Console.ReadLine());
           


            Console.WriteLine("/n");
        }
    }
}
