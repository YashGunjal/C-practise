﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2_reverse_the_array_original
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the length of array");
            int len = Convert.ToInt32(Console.ReadLine());
            int[] arr = new int[len];
            Console.WriteLine("enter element inarray");
            for (int i = 0; i < len; i++)
            {
                arr[i] = Convert.ToInt32(Console.ReadLine());
            }
            Array.Reverse(arr);
            foreach (int ele in arr)
            {
                Console.Write(ele);
            }

            Console.WriteLine("\nDone");
        }
    }
}
