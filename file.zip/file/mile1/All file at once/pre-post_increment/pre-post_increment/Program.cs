﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pre_post_increment
{
    class Program
    {
        static void Main(string[] args)
        {
            string input;
            //int letter =0, digit = 0, len =0;
            Console.WriteLine("Enter two numbers");


            input = (Console.ReadLine());
        }
    }
}
