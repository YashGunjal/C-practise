﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarClass
{
    class Car
    {
        private string carmake;   
        private string model;  
        private int mfgYear;
        private string price;

        public Car(string carmake23, string model, int mfgYear,string price)
        {
            carmake = carmake23;
            this.model = model;
            this.mfgYear = mfgYear;
            this.price = price;
        }

        public void DisplayCar()
        {
            Console.WriteLine("Car Maker : {0}\nModel : {1}\nManufacturing Year : {2}\nPrice : {3}",carmake,model,mfgYear,price);
        }
    }
}
