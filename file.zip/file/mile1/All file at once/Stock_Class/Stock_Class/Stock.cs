﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Stock_Class
{
    class Stock
    {
        private string StockName;
        private string StockSymbol;
        private double PreviousClosingPrice;
        private double CurrentClosingPrice;

        public Stock(string SN,string SS, double PCP,double CCP)
        {
            StockName = SN;
            StockSymbol = SS;
            PreviousClosingPrice = PCP;
            CurrentClosingPrice = CCP;
        }

        public double GetChangePercentage()
        {
            return ((PreviousClosingPrice - CurrentClosingPrice) / PreviousClosingPrice) * 100;
        }
    }
}
