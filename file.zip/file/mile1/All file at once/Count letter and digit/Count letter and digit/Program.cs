﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Count_letter_and_digit
{
    class Program
    {
        static void Main(string[] args)
        {
            string input;
            int letter = 0, digit = 0, len = 0;
            Console.WriteLine("Enter an Alphanumeric");

            input = Convert.ToString(Console.ReadLine());
            len = input.Length;
            for (int i = 0; i < len; i++)
            {
                if (Char.IsDigit(input, i))
                {
                    digit = digit + 1;
                }
                if (Char.IsLetter(input, i))
                {

                    letter = letter + 1;
                }

                //Console.WriteLine(input[i]);
                //Console.WriteLine((Char.IsLetter(input, i)));



            }
            Console.WriteLine("{0}", input.Length);
            Console.WriteLine("{0}", letter);
            Console.WriteLine("{0}", digit);
            Console.ReadKey();

        }
    }
}
