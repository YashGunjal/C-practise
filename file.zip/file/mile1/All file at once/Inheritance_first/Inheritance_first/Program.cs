﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Inheritance_first
{
    class Program
    {
        static void Main(string[] args)
        {
            
            Employee POTTER = new Employee(5000000,"Harry","POTTER","harry.potter@hogwarts.com",1991,12,6); 
        }
    }
}
