﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Text;
namespace InventoryManagementSystem
{
    public class Product
    {
        public int ProductID { get; set; }
        public string ProductName { get; set; }
        public string Description { get; set; }
        public int Quantity { get; set; }
        public int UnitPrice { get; set; }

        string ConnectionString = "Data Source=.;Initial Catalog=ProductsDB;User ID=sa;Password=wipro@123";

        public bool ADDProduct(Product obj)
        {
            SqlConnection con = new SqlConnection(ConnectionString);
            SqlCommand cmd = new SqlCommand("insert into products(productname,description,availablequantity,unitprice) values (@pn,@des,@ava,@up)", con);
            cmd.Parameters.AddWithValue("@pn", obj.ProductName);
            cmd.Parameters.AddWithValue("@des", obj.Description);
            cmd.Parameters.AddWithValue("@ava", obj.Quantity);
            cmd.Parameters.AddWithValue("@up", obj.UnitPrice);
            con.Open();
            int rows = cmd.ExecuteNonQuery();
            con.Close();
            if( rows == 1)
            {
                return true;
            }
            else
            {
                return false;
            }
        }


        public bool ModifyProduct(Product obj)
        {
            SqlConnection con = new SqlConnection(ConnectionString);
            SqlCommand cmd = new SqlCommand("update products set productname = @pn, description=@des, availablequantity = @ava, unitprice = @up where productid =  @pid", con);
            cmd.Parameters.AddWithValue("@pn", obj.ProductName);
            cmd.Parameters.AddWithValue("@des", obj.Description);
            cmd.Parameters.AddWithValue("@ava", obj.Quantity);
            cmd.Parameters.AddWithValue("@up", obj.UnitPrice);
            cmd.Parameters.AddWithValue("@pid", obj.ProductID);

            con.Open();
            int rows = cmd.ExecuteNonQuery();
            con.Close();
            if (rows == 1)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public bool DeleteProduct(int productID)
        {
            SqlConnection con = new SqlConnection(ConnectionString);
            SqlCommand cmd = new SqlCommand("delete from products where productID = @pid", con);
            cmd.Parameters.AddWithValue("@pid", productID);
            con.Open();
            int rows = cmd.ExecuteNonQuery();
            con.Close();
            if (rows == 1)
            {
                return true;
            }
            else
            {
                return false;
            }
        }


        public Product ViewProduct(int productID)
        {
            Product pro = null;
            SqlConnection con = new SqlConnection(ConnectionString);
            SqlCommand cmd = new SqlCommand("select * from products where productID = @pid", con);
            cmd.Parameters.AddWithValue("@pid", productID);
            con.Open();
            SqlDataReader dr= cmd.ExecuteReader();
            if (dr.HasRows)
            {
                dr.Read();
                pro = new Product();
                pro.ProductID = int.Parse(dr["productID"].ToString());
                pro.ProductName = dr["productname"].ToString();
                pro.Description = dr["description"].ToString();
                pro.Quantity = int.Parse(dr["availablequantity"].ToString());
                pro.UnitPrice = int.Parse(dr["unitprice"].ToString());
                return pro;
                
            }
            else
                {
                return pro;

            }
        }


        public List<Product> ViewAllProducts()
        {
            List<Product> lis = new List<Product>();
            SqlConnection con = new SqlConnection(ConnectionString);
            SqlCommand cmd = new SqlCommand("select * from products", con);
            //cmd.Parameters.AddWithValue("@pid", productID);
            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.HasRows)
            {
                while (dr.Read())
                {
                    Product pro = new Product();
                    pro.ProductID = int.Parse(dr["productID"].ToString());
                    pro.ProductName = dr["productname"].ToString();
                    pro.Description = dr["description"].ToString();
                    pro.Quantity = int.Parse(dr["availablequantity"].ToString());
                    pro.UnitPrice = int.Parse(dr["unitprice"].ToString());
                    lis.Add(pro);
                    
                }
                return lis;

            }
            else
            {
                return null;

            }

        }
    }
}
