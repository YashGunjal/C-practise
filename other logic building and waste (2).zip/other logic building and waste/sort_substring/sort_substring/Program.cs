﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/// <summary>
/// class one
/// </summary>
namespace sort_substring
{
    public class input{

        public string word;
        public int init;
        public int end;

        public input(string word, int init, int end)
        {
            this.word = word;
            this.init = init;
            this.end = end;

        }



    }
    class Program
    {
        static void Main(string[] args)
        {

            //dynamic input;
            Console.WriteLine( "Number of string you want to enter\n Insert format -> string initial_of_substring end_of_substring");
            int no_of_input = Convert.ToInt32(Console.ReadLine());
            string[,] values = new string[no_of_input,3];

            Dictionary<String, input> inputs = new Dictionary<string, input>();
            for (int  i=0;i<no_of_input;i++)
            {
                Console.WriteLine("enter word no.{0}",i+1);
                string temp  = (Console.ReadLine());

                //Console.WriteLine("Range 1 - {0}:",values[i,0].Length);
                string[] words = temp.Split(' ');

                inputs[String.Format("wordslice{0}", i)] = new input(words[0],int.Parse(words[1]),int.Parse(words[2]));
            }

            /* for (int i = 0; i < no_of_input; i++)
             {

                 Console.WriteLine(inputs[String.Format("wordslice{0}", i)].word); 
                 Console.WriteLine(inputs[String.Format("wordslice{0}", i)].init); 
                 Console.WriteLine(inputs[String.Format("wordslice{0}", i)].end);  
             }
             
            */
          

            for (int i = 0; i < no_of_input; i++)
            {
              
                Sortsubstring(inputs[String.Format("wordslice{0}", i)].word, inputs[String.Format("wordslice{0}", i)].init , inputs[String.Format("wordslice{0}", i)].end);


            }
           
        }
        public static string Sortsubstring(string s,int indexinit, int indexend)
        {
            int diff = indexend - indexinit;
            char[] arr = s.ToCharArray();
            Array.Sort(arr, indexinit - 1 ,  diff+1);
            Array.Reverse(arr, indexinit - 1, diff + 1);
            Console.Write(arr);
            Console.WriteLine();
            return new string(arr);
        }
    }





}