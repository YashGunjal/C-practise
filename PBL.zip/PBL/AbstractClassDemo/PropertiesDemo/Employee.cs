﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PropertiesDemo
{
    class Employee
    {
        int EmpID;
        string EmpName;

        public Employee()
        {
            EmpID = new Random().Next(1000, int.MaxValue);
        }

        public int EmployeeID
        {
            get { return EmpID; }
            //set { EmpID = value; }
        }

        //public void SetData()
        //{
        //    EmpID = int.Parse(Console.ReadLine());
        //    EmpName = Console.ReadLine();
        //}

        //public void Display()
        //{
        //    Console.WriteLine("Emp ID:"+EmpID);
        //    Console.WriteLine("Emp Name:"+EmpName);
        //}

        public string getEmpName()
        {
            return EmpName;
        }

        public void setEmpName(string strEmpName) 
        {
            EmpName = strEmpName;
        }

        public string EmployeeName
        {
            get { return EmpName; }
            set { EmpName = value; }
        }
    }
}
