﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GenericMethods
{
    class Program
    {
        static void Main(string[] args)
        {
            GenericMath<int> obj = new GenericMath<int>();
            Console.WriteLine(obj.Add(10, 20));

            GenericMath<double> objDouble = new GenericMath<double>();
            Console.WriteLine(objDouble.Add(1.23,2.34));

            GenericMath<int> objDynamic = new GenericMath<int>();            
        }
    }
}
