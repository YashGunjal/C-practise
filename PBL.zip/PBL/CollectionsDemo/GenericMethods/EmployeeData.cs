﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GenericMethods
{
    class EmployeeData
    {
        List<Employee> objEmployees = new List<Employee>();

        public bool AddEmployee(Employee objEmp)
        {
            bool isAdded = false;
            objEmployees.Add(objEmp);
            isAdded = true;
            return isAdded;
        }

        public bool DeleteEmployee(int id)
        {
            bool isDeleted = false;

            for (int i = 0; i < objEmployees.Count; i++)
            {
                if(objEmployees[i].EmployeeID==id)                
                {
                    objEmployees.RemoveAt(i);
                    isDeleted = true;
                }
            }

            return isDeleted;
        }

        public string SearchEmployee(int id)
        {
            string strEmpName = string.Empty;
            for (int i = 0; i < objEmployees.Count; i++)
            {               
                if (objEmployees[i].EmployeeID == id)
                {
                    strEmpName = objEmployees[i].EmployeeName;
                }
            }

            return strEmpName;
        }

        public Employee[] GetAllEmployees()
        {
            return objEmployees.ToArray();
        }

        public void Display()
        {
            IEnumerator<Employee> e = objEmployees.GetEnumerator();
            while (e.MoveNext())
            {                
                Console.WriteLine(e.Current.EmployeeID);
                Console.WriteLine(e.Current.EmployeeName);
            }
        }

        static void Main(string[] args)
        {
            EmployeeData objData = new EmployeeData();
            objData.AddEmployee(new Employee() { EmployeeID = 100, EmployeeName = "Smith" });
            objData.AddEmployee(new Employee() { EmployeeID = 101, EmployeeName = "John" });

            objData.Display();

            Console.WriteLine(objData.SearchEmployee(100));
            if (objData.DeleteEmployee(100))
                Console.WriteLine("Employee details deleted");
            else
                Console.WriteLine("Can't find / delete the details.");

            Employee[] a = objData.GetAllEmployees();
            foreach (Employee e in a)
            {
                Console.WriteLine(e.EmployeeID);
                Console.WriteLine(e.EmployeeName);
            }


        }
    }
}
