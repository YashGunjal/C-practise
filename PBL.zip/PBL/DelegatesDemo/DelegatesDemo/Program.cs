﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DelegatesDemo
{
    class Program
    {
        // Declare the delegate.
        

      
        static void Main(string[] args)
        {
            int[] input1 = { 11,4, 1, 4, 7, 8, 12, 3, 2, 1,12};
            int number_of_sequence = 0;
            int long_sequence = 0;
            int count = 1;
            int running = 0;
            Console.WriteLine(input1.Length);
            //foreach(var single in input1){
            int i = 1;// i < input1.Length; i++)
                do
                {
                Console.WriteLine("upp"+i);
                    running = input1[i];
                Console.WriteLine("running" +input1[i]);
                    if (input1[i - 1] > input1[i])
                    {
                        count += 1;
                    }
                    else
                    {
                        if (count > 1)
                        {
                            number_of_sequence += 1;

                            if (count > long_sequence)
                            {
                                long_sequence = count;
                            }
                            count = 1;
                        }
                    }
                i++;
                Console.WriteLine("below" +i);
                } while (i < input1.Length);
            if (count > 1)
            {
                number_of_sequence += 1;

                if (count > long_sequence)
                {
                    long_sequence = count;
                }
                count = 1;
            }

            Console.WriteLine(number_of_sequence);
            Console.WriteLine(long_sequence);
        
        }
    }
}
   
