﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FileStreamIO
{
    class FileOperations
    {
        public static void Main()
        {
            Console.Write("Enter file name:");
            string strFileName = Console.ReadLine();

            Console.Write("Enter File Mode:\n1. Open\t2. Create");
            int intChoice = int.Parse(Console.ReadLine());

            switch (intChoice)
            {
                case 1:
                    try
                    {
                        FileStream objStream = new FileStream(strFileName, FileMode.Open);
                        StreamReader objReader = new StreamReader(objStream);
                        string str = objReader.ReadToEnd();
                        Console.WriteLine(str);
                        objReader.Close();
                        objStream.Close();
                    }
                    catch (FileNotFoundException exp)
                    {
                        Console.WriteLine(exp.Message);
                    }
                    break;
                case 2:
                    FileStream objReaderStream = new FileStream(strFileName, FileMode.Create);
                    StreamWriter objWriter = new StreamWriter(objReaderStream);
                    Console.Write("File created successfully. Please enter content to save.");
                    string strContent = Console.ReadLine();
                    objWriter.Write(strContent);
                    objWriter.Close();
                    objReaderStream.Close();
                    break;
            }
            
        }
    }
}
