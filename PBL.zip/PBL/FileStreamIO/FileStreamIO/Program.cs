﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FileStreamIO
{
    class Program
    {
        static void Main(string[] args)
        {
            FileStream objStream = new FileStream("Demo.txt", FileMode.Create);
            StreamWriter objWriter = new StreamWriter(objStream);
            objWriter.Write("Welcome to Stream based IO operations");
            objWriter.Close();
            objStream.Close();
            Console.WriteLine("File created successfully...");

            FileStream objReaderStream = new FileStream("Demo.txt", FileMode.Open);
            StreamReader objReader = new StreamReader(objReaderStream);
            string strContent=objReader.ReadToEnd();
            objReader.Close();
            objReaderStream.Close();
            Console.WriteLine(strContent);
        }
    }
}
