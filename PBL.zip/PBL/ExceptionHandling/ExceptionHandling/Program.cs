﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExceptionHandling
{
    class Program
    {
        static void Main(string[] args)
        {
            int a = 20;
            int b = 10;
            try
            {
                Console.Write("Enter first value:");
                a = int.Parse(Console.ReadLine());

                Console.Write("Enter second value:");
                b = int.Parse(Console.ReadLine());

                int c = a / b;
                Console.WriteLine(c);
            }
            //catch (FormatException expFormat)
            //{
            //    Console.WriteLine("Please enter valid integrals");
            //}

            catch (DivideByZeroException exp)
            {
                Console.WriteLine("Can't divide a number by zero");
                Console.WriteLine(exp.Message);
                Console.WriteLine(exp.StackTrace);
            }
            catch (Exception expGeneric)
            {
                Console.WriteLine(expGeneric.Message);
            }
            finally
            {
                Console.WriteLine("Resource cleanup");
            }
            Console.WriteLine("Completed");
        }
    }
}
