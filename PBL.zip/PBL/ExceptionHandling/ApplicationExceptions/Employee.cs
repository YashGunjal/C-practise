﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApplicationExceptions
{
    class Employee
    {
        public int EmployeeID { get; set; }
        public string EmployeeName { get; set; }
        private int age;

        public int Age
        {
            get { return age; }
            set {
                if (value < 18)
                {
                    throw new AgeException("Age should be more than or equal to 18");
                }
            }
        }

        //public void SetData()
        //{
        //    try
        //    {
        //        Console.Write("Enter ID:");
        //        EmployeeID = int.Parse(Console.ReadLine());

        //        Console.Write("Enter Name:");
        //        EmployeeName = Console.ReadLine();

        //        Console.Write("Enter Age:");
        //        Age = int.Parse(Console.ReadLine());
        //        if (Age < 18)
        //        {
        //            AgeException objException = new AgeException("Age shouldn't be less than 18");
        //            throw objException;
        //        }
        //    }
        //    catch (FormatException expFormat)
        //    {
        //        Console.WriteLine("Pls. enter input in valid formts");
        //    }
        //    catch (AgeException expAge)
        //    {
        //        Console.WriteLine(expAge.Message);
        //        Console.WriteLine(expAge.StackTrace);
        //    }
        //}
    }
}
