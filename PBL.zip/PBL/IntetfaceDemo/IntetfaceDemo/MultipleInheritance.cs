﻿using System;

namespace IntetfaceDemo
{
    interface Interface1
    {
        void Display();
    }

    interface Interface2
    {
        void Display();
    }
    class MultipleInheritance: Interface1, Interface2
    {
        void Interface1.Display()
        {
            Console.WriteLine("Display from Interace 1");
        }

        void Interface2.Display()
        {
            Console.WriteLine("Display from Interface 2");
        }

        static void Main(string[] args)
        {
            MultipleInheritance obj = new MultipleInheritance();            

            Interface1 obj1 = obj;
            obj1.Display();

            Interface2 obj2 = obj;
            obj2.Display();
        }
    }
}
