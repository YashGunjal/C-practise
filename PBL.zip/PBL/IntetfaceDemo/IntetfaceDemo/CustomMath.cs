﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IntetfaceDemo
{
    class CustomMath : IMath
    {
        public void Add(int a, int b)
        {
            Console.WriteLine("Sum is:"+(a+b));
        }

        public void Subtract(int a, int b)
        {
            Console.WriteLine("Diff is:"+(a-b)); 
        }
    }
}
