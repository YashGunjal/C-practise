﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EarlyBindingDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            CustomMath obj = new CustomMath();
            Console.WriteLine("Sum of Array:"+obj.Add(new int[] {10,20,30 }));
            Console.WriteLine("Sum of Numbers:"+obj.Add(10,20));
            Console.WriteLine("Sum of Strings:"+obj.Add("Wipro","Tech"));
        }
    }
}
