﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeManagement
{
    class Program
    {
        static void Main(string[] args)
        {
            EmployeeData obj = new EmployeeData();
            obj.AddEmployee(new Employee("John", "Smith", 2012, 12, 01, "Msc", 10.0));
        }
    }
}
