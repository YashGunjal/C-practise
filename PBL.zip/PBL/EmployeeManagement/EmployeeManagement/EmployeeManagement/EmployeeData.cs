﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeManagement
{
    public class EmployeeData
    {
        //TODO : Write your code here.
        public List<Employee> EmployeeList { get; set; }

        public EmployeeData()
        {
            // TODO: Write your code here.
            EmployeeList = new List<Employee>();
        }
        public string AddEmployee(Employee obj)
        {
            if (obj == null)
                return null;
            else
            {
                Utility.EmployeeUtility objUtility = new Utility.EmployeeUtility();
                objUtility.GenerateUserName(obj, 1);
                EmployeeList.Add(obj);
                return obj.UserID;
            }
        }

        public bool ModifyEmployee(Employee obj)
        {
            bool IsModified = false;
            if (obj == null)
                IsModified = false;
            else
            {
                for (int i = 0; i < EmployeeList.Count; i++)
                {
                    if (EmployeeList[i].UserID == obj.UserID)
                    {
                        EmployeeList[i] = obj;
                        IsModified = true;
                    }
                }
            }

            return IsModified;
        }

        public Employee SearchEmployee(string strUserID)
        {
            Employee objResult = null;
            if (string.IsNullOrEmpty(strUserID))
            {
                return null;
            }
            else
            {
                for (int i = 0; i < EmployeeList.Count; i++)
                    if (EmployeeList[i].UserID == strUserID)
                    {
                        objResult = EmployeeList[i];
                    }
            }

            return objResult;
        }

        public bool DeleteEmployee(string strUserID)
        {
            bool isDeleted = false;

            if (string.IsNullOrEmpty(strUserID))
                return false;
            else
            {
                for (int i = 0; i < EmployeeList.Count; i++)
                    if (EmployeeList[i].UserID == strUserID)
                    {
                        EmployeeList.RemoveAt(i);
                        isDeleted = true;
                    }
            }

            return isDeleted;
        }
    }
}
