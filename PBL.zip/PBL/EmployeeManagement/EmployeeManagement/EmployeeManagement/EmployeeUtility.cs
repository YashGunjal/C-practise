﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeManagement.Utility
{
    public class EmployeeUtility
    {
        public void GenerateUserName(Employee obj,int EmployeeCount)
        {
            string strUserID = ((char)(obj.FirstName[0]+obj.FirstName.Length)).ToString() + ((char)(obj.LastName[0]+obj.LastName.Length)).ToString();
            strUserID += SumDigits(obj.BirthYear) + SumDigits(obj.BirthMonth) + SumDigits(obj.BirthDay);
            strUserID += EmployeeCount;
            obj.UserID = strUserID;
        }

        public string SumDigits(int value)
        {
            int sum = 0;
            while (value != 0)
            {
                sum += value % 10;
                value /= 10;
            }

            return sum.ToString();
        }
    }
}
